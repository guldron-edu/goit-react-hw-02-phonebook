import React, { Component } from "react";
import PropTypes from "prop-types";
import styles from "./InputForm.module.css";

export default class InputForm extends Component {
  static propTypes = {
    addNewContact: PropTypes.func,
  };

  state = {
    name: "",
    number: "",
  };
  inputTracking = (ev) => {
    ev.preventDefault();
    this.setState({ [ev.target.name]: ev.target.value });
  };

  submitForm = (ev) => {
    ev.preventDefault();

    this.props.addNewContact(this.state.name, this.state.number);
    this.resetInputForm();
  };

  resetInputForm = () => {
    this.setState({ name: "", number: "" });
  };

  render() {
    return (
      <form className={styles.inputForm} onSubmit={this.submitForm}>
        <label className={styles.label}>
          Name
          <input
            className={styles.input}
            type="input"
            name="name"
            minLength={3}
            required
            onChange={this.inputTracking}
            value={this.state.name}
            autoFocus
          ></input>
        </label>
        <label className={styles.label}>
          Number
          <input
            className={styles.input}
            type="number"
            name="number"
            minLength={10}
            required
            onChange={this.inputTracking}
            value={this.state.number}
          ></input>
        </label>
        <button className={styles.btn} type={"submit"}>
          Add contact
        </button>
      </form>
    );
  }
}
