import React from "react";
import PropTypes from "prop-types";

import styles from "./Contacts.module.css";

export default function Contacts({ visibleContacts, deleteContact }) {
  return (
    <ul className={styles.list}>
      {visibleContacts.map((contact) => (
        <li key={contact.id} className={styles.item}>
          <span>
            {firstLetters(contact.name)}: {contact.number}
          </span>
          <button
            type="button"
            className={styles.btn}
            onClick={() => deleteContact(contact.id)}
          >
            Delete
          </button>
        </li>
      ))}
    </ul>
  );
}

function firstLetters(phrase) {
  return phrase
    .split(" ")
    .map((word) => {
      return word[0].toUpperCase() + word.substring(1).toLowerCase();
    })
    .join(" ");
}

Contacts.propTypes = {
  deleteContact: PropTypes.func,
  visibleContacts: PropTypes.arrayOf(
    PropTypes.exact({
      id: PropTypes.string,
      name: PropTypes.string,
      number: PropTypes.string,
    })
  ),
};
